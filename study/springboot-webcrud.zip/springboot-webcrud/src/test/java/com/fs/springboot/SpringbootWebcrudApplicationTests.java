package com.fs.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebcrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
