package com.fs.demo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fs.demo.mapper.UserMapper;
import com.fs.demo.entity.MpUser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

@SpringBootTest
class DemoApplicationTests {

    @Autowired
    private UserMapper userMapper;

    /**
     * 查询出所有用户
     */
    @Test
    void seletAll() {
        List<MpUser> userList=userMapper.selectList(null);
        userList.forEach(System.out::println);
    }

    /**
     * 通过单个ID主键进行查询
     */
    @Test
    public void selectById(){
        MpUser user = userMapper.selectById(1087982257332887553L);
        System.out.println(user);
    }
    /**
     * 通过多个ID主键进行查询
     */
    @Test
    public void selectByList(){
        List<Long> ids = Arrays.asList(1094590409767661570L,1094592041087729666L);
        List<MpUser> userList = userMapper.selectBatchIds(ids);
        userList.forEach(System.out::println);
    }

    /**
     * 通过map参数进行查询
     */
    @Test
    public void selectByMap(){
        Map<String,Object> params = new HashMap<>();
        params.put("name","大boss");
        List<MpUser> users = userMapper.selectByMap(params);
        users.forEach(System.out::println);
    }

    /**
     * Wrapper条件构造器
     */

    /**
     * 名字包含雨并且年龄小于40
     * where name like '%雨%' and age <40
     */
    @Test
    public void selectByWrapperOne(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.like("name","雨").lt("age",40);
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 名字包含雨，年龄大于20小于40，邮箱不为空
     * where name like '%雨%' and age between 20 and 40 and email is not null
     */
    @Test
    public void selectByWrapperTwo(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.like("name","雨").between("age",20,40).isNotNull("email");
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 姓氏为王，或者年龄大于等于25，按照年龄降序排序，年龄相同按照id升序排序
     *
     * where name like '王%' or age>25 order by age DESC, id ASC
     *
     */

    @Test
    public void selectByWrapperThree(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.likeRight("name",'王').or().ge("age",25).orderByDesc("age").orderByAsc("id");
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 查询创建时间为2019年2月14日
     * 并且上级领导姓王
     *
     * WHERE date_format(create_time,'%Y-%m-%d') = '2019-02-14' AND manager_id IN (select id from user where name like '王%')
     */
    @Test
    public void selectByWrapperFour(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.apply("date_format(create_time,'%Y-%m-%d')={0}","2019-02-14").inSql("manager_id","select id from mp_user where name like '王%'");
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 查询王姓
     * 并且年龄小于40或者邮箱不为空
     *
     * where name like '王%' and (age<40 or email is not null)
     */

    @Test
    public void selectByWrapperFive(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.likeRight("name","王").and(qw -> qw.lt("age",40).or().isNotNull("email"));
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 年龄小于40或者邮箱不为空 并且姓王
     * where (age<40 or email is not null) and name like '王%'
     */

    @Test
    public void selectByWrapperSix(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.nested(qw->qw.lt("age",40).or().isNotNull("email")).likeRight("name","王");
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 查询年龄为30, 31, 32
     * where age in(?, ?, ?)
     */
    @Test
    public void selectByWrapperSeven(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.in("age",Arrays.asList(30,31,32));
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }

    /**
     * 查询1条数据
     * Limit 1
     */
    @Test
    public void selectByWrapperEight(){
        QueryWrapper<MpUser> wrapper = new QueryWrapper();
        wrapper.in("age",Arrays.asList(30,31,32)).last("limit 1");
        List<MpUser> userList = userMapper.selectList(wrapper);
        userList.forEach(System.out::println);
    }
    
    @Test
    public void selectLambda(){
        //LambdaQueryWrapper lambda = new QueryWrapper().lambda();
        //LambdaQueryWrapper lambdaQueryWrapper = new LambdaQueryWrapper();
        LambdaQueryWrapper<MpUser> lambdaQuery = Wrappers.<MpUser>lambdaQuery();
        lambdaQuery.like(MpUser::getName,"雨").lt(MpUser::getAge,40);
        List<MpUser> userList = userMapper.selectList(lambdaQuery);
        userList.forEach(System.out::println);
    }
}
