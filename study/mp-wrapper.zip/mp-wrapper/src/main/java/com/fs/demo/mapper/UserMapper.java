package com.fs.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fs.demo.entity.MpUser;
import org.apache.ibatis.annotations.Mapper;

public interface UserMapper extends BaseMapper <MpUser>{
}
