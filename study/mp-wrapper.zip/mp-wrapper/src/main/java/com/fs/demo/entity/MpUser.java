package com.fs.demo.entity;

import lombok.Data;

import java.util.Date;

@Data
public class MpUser {

    private Long id;

    private String name;

    private Integer age;

    private String email;

    private Long managerId;

    private Date createTime;
}
