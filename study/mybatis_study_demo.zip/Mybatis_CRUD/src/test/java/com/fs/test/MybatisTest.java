package com.fs.test;

import com.fs.dao.IUserDao;
import com.fs.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * 测试Mybatis的CRUD操作
 */
public class MybatisTest {
    private InputStream in;
    private SqlSession sqlSession;
    private IUserDao userDao;

    @Before //用于在测试方法之前执行
    public void init() throws IOException {
        //1.读取配置文件
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2.创建SqlSessionFactory工厂
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);
        //3.使用工厂生产SqlSession对象
        sqlSession = factory.openSession();
        //4.使用SqlSession创建Dao接口的代理对象
        userDao = sqlSession.getMapper(IUserDao.class);
    }
    @After //用于在测试方法之后执行
    public void destroy() throws IOException {
        //提交事务
        sqlSession.commit();
        //关闭资源
        sqlSession.close();
        in.close();
    }

    public void testFindAll() {
        List<User> users = userDao.findAll();
        for(User user:users){
            System.out.println(user);
        }

    }

    public void testSave() throws IOException {
        User user = new User();
        user.setUsername("mybatis saveuser");
        user.setAddress("北京市");
        user.setSex("男");
        user.setBirthday(new Date());
        //执行保存方法
        userDao.saveUser(user);
    }

    public  void testUpdate(){
        User user = new User();
        user.setId(50);
        user.setUsername("mybatis updateuser");
        user.setAddress("北京市");
        user.setSex("女");
        user.setBirthday(new Date());
        //执行保存方法
        userDao.updateUser(user);
    }

    public  void testDelete(){

        //执行删除方法
        userDao.deleteUser(52);
    }
    @Test
    public  void testFindById(){

        //执行根据ID查询用户的方法
        User user = userDao.findById(50);
        System.out.println(user);
    }

}
